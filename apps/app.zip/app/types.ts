export type Event = {
    id: string;
    name: string;
    genre: string;
    date: string;
    location: string;
    createdAt: string;
    updatedAt: string;
};
