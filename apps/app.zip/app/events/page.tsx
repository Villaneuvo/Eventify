export default function Page() {
  return (
    <>
      <h1>Page</h1>
    </>
  );
}
