import PaymentDetail from "@/app/components/section/ticket-payment/ticket-payment";

export default function Page() {
  return (
    <>
      <PaymentDetail />
    </>
  );
}
